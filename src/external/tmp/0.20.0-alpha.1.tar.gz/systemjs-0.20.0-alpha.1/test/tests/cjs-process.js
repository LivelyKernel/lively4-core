exports.env = {
  NODE_ENV: 'dev'
};