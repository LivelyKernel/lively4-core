import c from "./c.js";

export default {
	name: "b",
	c: c
};
