// a.js 
var c = require("./c.js");
var b = require('./b.js');

module.exports = {
	name: "a",
	b: b,
	c: c
};
