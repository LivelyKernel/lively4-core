require('./self-load.js');
module.exports = 'dirindex';