System.register("tests/foo.js", [], function($__export) {
  "use strict";
  var __moduleName = "foo";
  return {
    setters: [],
    execute: function() {
      $__export('f', 'f');
    }
  };
});
