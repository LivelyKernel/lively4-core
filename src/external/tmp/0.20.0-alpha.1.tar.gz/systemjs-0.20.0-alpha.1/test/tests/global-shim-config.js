(function(window) {
  window.ME = dep;
})(typeof window != 'undefined' ? window : global);