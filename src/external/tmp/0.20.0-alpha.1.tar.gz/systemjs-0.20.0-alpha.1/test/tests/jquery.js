var a = 'a';
module.exports = require(a);