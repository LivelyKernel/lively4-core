export var pi = 'π';
export var emoji = '🐶';
