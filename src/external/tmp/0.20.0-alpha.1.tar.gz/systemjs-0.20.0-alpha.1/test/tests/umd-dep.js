define({
  dep: 'hi'
})