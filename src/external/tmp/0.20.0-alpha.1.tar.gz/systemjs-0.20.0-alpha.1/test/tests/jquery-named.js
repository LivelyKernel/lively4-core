define('jquery-named', function() {
  return { is: 'jquery' };
});