System.register([], function(_export, _context) {
  return {
    setters: [],
    execute: function() {
      _export('name', _context.id);
    }
  };
})