define(['./all-layers2.js'], function(al2) {
  return al2.q == 10 && al2.r == 5;
});