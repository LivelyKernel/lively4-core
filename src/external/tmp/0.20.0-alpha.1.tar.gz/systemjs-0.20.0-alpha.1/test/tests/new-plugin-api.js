module.exports = function (key) {
  return this.newModule({ hello: 'world' });
};
