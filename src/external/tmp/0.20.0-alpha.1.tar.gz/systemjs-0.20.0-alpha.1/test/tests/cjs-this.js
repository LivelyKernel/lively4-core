"format cjs";
this.asdf = 'module value';