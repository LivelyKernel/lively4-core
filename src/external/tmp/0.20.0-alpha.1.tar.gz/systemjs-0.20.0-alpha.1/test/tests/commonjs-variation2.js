Object.defineProperties(module.exports, {
  OpaqueToken: {get: function() {
      return OpaqueToken;
    }},
  __esModule: {value: true}
});

function OpaqueToken() {}