(function(window) {
  window.q = {
    r: 'r'
  };
})(typeof window != 'undefined' ? window : global);