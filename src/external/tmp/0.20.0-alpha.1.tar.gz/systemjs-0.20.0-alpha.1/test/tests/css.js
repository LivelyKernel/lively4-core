exports.instantiate = function(load) {
  return { pluginSource: load.source };
}