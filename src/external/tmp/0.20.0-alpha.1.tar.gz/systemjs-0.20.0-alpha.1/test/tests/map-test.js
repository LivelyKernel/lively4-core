exports.maptest = require('./map-test-dep.js').dep;
