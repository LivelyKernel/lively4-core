define('jquery', function() {
  return { name: 'jquery-bundled' };
});