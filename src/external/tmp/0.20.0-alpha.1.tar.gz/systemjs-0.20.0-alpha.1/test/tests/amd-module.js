define(['./amd-dep.js'], function (d) {
  return {
    dep: d,
    amd: true
  };
});
