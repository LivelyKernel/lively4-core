export var c = 3;
import { p } from './es6-circular1.js';
p();
