define(function(require, exports) {
  var p = require('./amd-dep.js');
  exports.test = 'hi';
});